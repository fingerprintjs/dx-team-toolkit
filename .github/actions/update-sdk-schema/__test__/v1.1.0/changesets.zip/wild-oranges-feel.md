---
'fingerprint-pro-server-api-openapi': minor
---

**events**: Introduce `PUT` endpoint for `/events` API
